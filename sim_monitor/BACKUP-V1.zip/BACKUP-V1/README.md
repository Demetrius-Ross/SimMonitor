Ramp State:

    0: Ramp is in motion (neither fully up nor fully down).
    1: Ramp is up.
    2: Ramp is down.

Motion State:

    1: Simulator is "home" (simulator is down).
    2: Simulator is "up" (in motion or at an active state).

Status:

    0: No data.
    1: Connected (data is valid and received).